import unittest
from app import app, affordability, subsidy_scenario

class FairFareCalculationTests(unittest.TestCase):
    def test_affordability_percentage(self):
        result = affordability(10000, 1500)
        self.assertEqual(result["transport_share_percent"], 15.0)
        self.assertEqual(result["illustrative_band"], "high")

    def test_zero_transport_cost(self):
        result = affordability(10000, 0)
        self.assertEqual(result["transport_share_percent"], 0.0)
        self.assertEqual(result["illustrative_band"], "lower")

    def test_reject_zero_income(self):
        with self.assertRaises(ValueError):
            affordability(0, 100)

    def test_reject_negative_cost(self):
        with self.assertRaises(ValueError):
            affordability(10000, -1)

    def test_support_scenario(self):
        result = subsidy_scenario(1200, 300)
        self.assertEqual(result["estimated_remaining_cost"], 900.0)
        self.assertEqual(result["cost_covered_percent"], 25.0)

    def test_support_cannot_make_cost_negative(self):
        result = subsidy_scenario(100, 500)
        self.assertEqual(result["estimated_remaining_cost"], 0.0)
        self.assertEqual(result["cost_covered_percent"], 100.0)

class FairFareApiTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_homepage(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)

    def test_affordability_api(self):
        response = self.client.post('/api/affordability', json={"monthly_income": 10000, "monthly_transport_cost": 1000})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["transport_share_percent"], 10.0)

    def test_invalid_api_input(self):
        response = self.client.post('/api/affordability', json={"monthly_income": 0, "monthly_transport_cost": 100})
        self.assertEqual(response.status_code, 400)

    def test_sample_data_api(self):
        response = self.client.get('/api/sample-data')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.get_json()["records"]), 4)

if __name__ == '__main__':
    unittest.main()
