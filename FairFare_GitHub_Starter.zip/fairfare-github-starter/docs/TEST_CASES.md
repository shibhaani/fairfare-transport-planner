# Test Cases

Run the automated suite with `python -m unittest discover -s tests -v`.

| ID | Scenario | Input | Expected result |
|---|---|---|---|
| TC-01 | Calculate 15% transport share | Income 10000; cost 1500 | 15.0%; illustrative band `high` |
| TC-02 | Zero transport cost | Income 10000; cost 0 | 0.0%; illustrative band `lower` |
| TC-03 | Reject zero income | Income 0; cost 100 | `ValueError` in function; HTTP 400 in API |
| TC-04 | Reject negative cost | Income 10000; cost -1 | `ValueError` |
| TC-05 | Calculate support scenario | Cost 1200; support 300 | Remaining cost 900; coverage 25% |
| TC-06 | Cap support at total cost | Cost 100; support 500 | Remaining cost 0; coverage 100% |
| TC-07 | Homepage loads | GET `/` | HTTP 200 |
| TC-08 | Valid affordability API request | Income 10000; cost 1000 | HTTP 200; share 10% |
| TC-09 | Invalid affordability API request | Income 0; cost 100 | HTTP 400 |
| TC-10 | Sample data endpoint | GET `/api/sample-data` | HTTP 200; four synthetic records |

These are defined automated checks. Run them in your environment before claiming they passed there.
