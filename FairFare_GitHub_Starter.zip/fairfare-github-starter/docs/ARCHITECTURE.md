# FairFare Technical Design

## Purpose and scope
FairFare is an educational prototype for exploring transport affordability using user-entered values and fictional sample data. It is not an official eligibility system and must not be used to decide, deny, or withdraw benefits.

## Architecture

```mermaid
flowchart TD
    U[User] --> UI[Browser UI: HTML, CSS, JavaScript]
    UI --> API[Flask HTTP API]
    API --> CALC[Affordability calculation]
    API --> SCEN[Hypothetical subsidy scenario]
    API --> CSV[Read-only synthetic CSV sample data]
    CALC --> JSON[JSON response]
    SCEN --> JSON
    CSV --> JSON
    JSON --> UI
```

## Components
- **Browser interface:** collects approximate monthly income and transport costs; displays calculated results.
- **Flask API:** validates inputs and exposes `/api/affordability`, `/api/scenario`, and `/api/sample-data`.
- **Calculation functions:** deterministic arithmetic with validation for zero income and negative values.
- **Sample data:** fictional records stored in `data/sample_commuters.csv`; no real personal records are included.
- **Tests:** Python `unittest` covers calculation boundaries and API responses.

## Data flow
1. A user enters values in the browser.
2. JavaScript sends a JSON request to the local Flask API.
3. The API validates values and calculates a ratio or hypothetical scenario.
4. The API returns JSON; the browser displays the result.

## Privacy and limitations
- No database, accounts, analytics, or external API calls are used.
- The demo does not save user-entered values to a server-side database.
- The affordability bands (under 8%, 8–14.99%, and 15% or more) are illustrative, not official thresholds or evidence-based classifications.
- Sample rows are synthetic and must not be presented as survey results.
- A real deployment would require stakeholder research, accessibility testing, security review, lawful data governance, and policy expert review.

## Environment variables
- `FLASK_HOST`: bind host; defaults to `127.0.0.1`.
- `FLASK_PORT`: port; defaults to `5000`.
- `FLASK_DEBUG`: set to `true` only for local development; defaults to `false`.

No secret keys or external credentials are required for this prototype.
