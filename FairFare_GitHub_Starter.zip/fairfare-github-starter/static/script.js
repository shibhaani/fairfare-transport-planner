async function postJSON(path, payload) {
  const response = await fetch(path, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
function show(id, html) { const el = document.getElementById(id); el.innerHTML = html; el.style.display = 'block'; }
function money(value) { return '₹' + Number(value).toLocaleString('en-IN', {maximumFractionDigits: 2}); }
document.getElementById('affordability-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const data = await postJSON('/api/affordability', {monthly_income: document.getElementById('income').value, monthly_transport_cost: document.getElementById('transport-cost').value});
    show('affordability-result', `<div class="big">${data.transport_share_percent}%</div><strong>of entered monthly income</strong><p>Illustrative band: ${data.illustrative_band}. ${data.note}</p>`);
  } catch (error) { show('affordability-result', `<strong>Check your input:</strong> ${error.message}`); }
});
document.getElementById('scenario-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const data = await postJSON('/api/scenario', {monthly_transport_cost: document.getElementById('scenario-cost').value, hypothetical_support: document.getElementById('support').value});
    show('scenario-result', `<div class="big">${money(data.estimated_remaining_cost)}</div><strong>estimated remaining cost</strong><p>Hypothetical support covers ${data.cost_covered_percent}% of entered cost. ${data.note}</p>`);
  } catch (error) { show('scenario-result', `<strong>Check your input:</strong> ${error.message}`); }
});
document.getElementById('load-sample').addEventListener('click', async () => {
  const target = document.getElementById('sample-output');
  try {
    const response = await fetch('/api/sample-data'); const data = await response.json();
    const rows = data.records.map(row => `<tr><td>${row.example_group}</td><td>${money(row.monthly_income_inr)}</td><td>${money(row.monthly_transport_cost_inr)}</td></tr>`).join('');
    target.innerHTML = `<p class="small">${data.data_type}</p><table><thead><tr><th>Example group</th><th>Monthly income</th><th>Transport cost</th></tr></thead><tbody>${rows}</tbody></table>`;
  } catch (_) { target.textContent = 'Could not load sample data. Start the Flask app and try again.'; }
});
document.querySelectorAll('form').forEach(form => form.dispatchEvent(new Event('submit', {cancelable: true})));
