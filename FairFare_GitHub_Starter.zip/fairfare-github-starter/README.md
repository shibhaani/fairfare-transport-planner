# FairFare — Inclusive Public Transport Affordability Planner

**Status:** Early student prototype / proof of concept.  
**Theme:** Governance and Inclusive Technology.  
**SDG alignment:** SDG 10 (Reduced Inequalities), SDG 11 (Sustainable Cities and Communities), SDG 8 (Decent Work and Economic Growth).

## Problem context
Transport expenses can create pressure for commuters with low or irregular incomes, including daily-wage workers. FairFare explores how a transparent affordability calculator and hypothetical scenario comparisons might help policy discussions about access to essential transport.

## What this prototype does
- Calculates transport expenses as a percentage of entered monthly income.
- Shows a clearly labelled illustrative affordability band.
- Compares a hypothetical support amount with entered monthly travel costs.
- Displays fictional sample commuter records.
- Includes input validation and automated tests.

## What it does not do
- It is not an official government service or eligibility checker.
- It does not determine, approve, deny, or withdraw benefits.
- It does not claim that a specific subsidy model is optimal.
- It contains no real survey data and makes no claims about measured impact.
- It does not store personal data or require Aadhaar, bank, or government-ID details.

## Tech stack
- Python 3.10 or newer
- Flask
- HTML, CSS, JavaScript
- CSV for fictional sample data
- Python `unittest` for tests

## Setup instructions

### 1. Get the code
Clone your repository, or download this project folder.

```bash
git clone <YOUR_REPOSITORY_URL>
cd <YOUR_REPOSITORY_FOLDER>
```

### 2. Create and activate a virtual environment

**Windows (PowerShell):**
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
```

**macOS/Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies
```bash
python -m pip install -r requirements.txt
```

### 4. Configure optional environment variables
Copy `.env.example` to `.env` if you want to keep local settings documented. The app does not automatically load `.env`; export variables in your shell or use the defaults. Available settings:
- `FLASK_HOST` (default `127.0.0.1`)
- `FLASK_PORT` (default `5000`)
- `FLASK_DEBUG` (default `false`; use `true` only for local development)

Example on macOS/Linux:
```bash
export FLASK_HOST=127.0.0.1
export FLASK_PORT=5000
export FLASK_DEBUG=false
```

### 5. Run the app
```bash
python app.py
```
Open `http://127.0.0.1:5000` in your browser.

### 6. Run tests
In a separate terminal with the virtual environment activated:
```bash
python -m unittest discover -s tests -v
```

## Repository structure
```text
fairfare/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── LICENSE
├── data/
│   └── sample_commuters.csv
├── docs/
│   ├── ARCHITECTURE.md
│   └── TEST_CASES.md
├── static/
│   ├── index.html
│   ├── styles.css
│   └── script.js
└── tests/
    └── test_app.py
```

## Architecture and tests
See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the architecture diagram, components, data flow, privacy notes, and environment variables. See [`docs/TEST_CASES.md`](docs/TEST_CASES.md) for the test plan.

## Sample data
`data/sample_commuters.csv` contains fictional examples only. Do not treat it as real survey data or use it to make policy conclusions.

## Responsible-use note
The affordability bands in this prototype are arbitrary demonstration bands, not official or validated measures. A real policy tool would require research with affected communities, accessibility testing, legal and privacy review, and expert evaluation. The project is intended to complement discussion of existing welfare programmes, not to advocate automatically removing benefits from any group.

## License
Released under the MIT License. See [`LICENSE`](LICENSE).
